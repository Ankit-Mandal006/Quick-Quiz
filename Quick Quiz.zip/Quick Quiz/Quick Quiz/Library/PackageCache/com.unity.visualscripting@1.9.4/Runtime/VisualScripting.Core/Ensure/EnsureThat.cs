namespace Unity.VisualScripting
{
    public partial class EnsureThat
    {
        internal string paramName;
    }
}

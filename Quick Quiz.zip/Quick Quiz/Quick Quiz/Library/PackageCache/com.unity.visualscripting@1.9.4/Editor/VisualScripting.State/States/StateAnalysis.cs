namespace Unity.VisualScripting
{
    public sealed class StateAnalysis : GraphElementAnalysis
    {
        public bool isEntered { get; set; }
    }
}

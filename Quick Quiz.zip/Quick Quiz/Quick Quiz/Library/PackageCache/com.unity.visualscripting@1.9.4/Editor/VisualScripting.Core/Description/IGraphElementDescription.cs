namespace Unity.VisualScripting
{
    public interface IGraphElementDescription : IDescription
    {
    }
}

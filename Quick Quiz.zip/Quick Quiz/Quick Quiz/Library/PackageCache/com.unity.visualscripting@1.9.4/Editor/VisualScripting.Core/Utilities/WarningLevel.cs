namespace Unity.VisualScripting
{
    public enum WarningLevel
    {
        Info = 1,
        Caution = 2,
        Severe = 3,
        Error = 4
    }
}

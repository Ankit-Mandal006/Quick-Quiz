namespace Unity.VisualScripting
{
    public interface IDropdownOption
    {
        object value { get; }
    }
}
